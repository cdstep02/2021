﻿//Grade ID: K5060
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace Exam2_S21
{
    class Program
    {
        static void Main(string[] args)
        {
            // The parallel arrays to be searched

            string[] states = { "Wisconsin" , "Minnesota", "Utah", "Kentucky", "Maine",

                "Ohio", "California", "Kansas", "Georgia", "Alaska" };

            string[] level = { "High" , "High", "High", "High", "Medium",

                "Medium", "Medium", "Low", "Low", "Low"  };

            string[] manufacturer = { "Pfizer" , "Pfizer", "Moderna", "Pfizer", "Moderna",

                "Pfizer", "Pfizer", "Moderna", "Pfizer", "Pfizer"  };
            //prompt
            string inputString;
            bool isState = false;
            Write("Enter name of state:");
            inputString = ReadLine();
            for (int x = 0; x < states.Length; ++x)
            { if (inputString == states[x])
                {
                    WriteLine("The assessed distribution level in {0} state is {1}. The primary manufacturer is {2}.", inputString, level[x], manufacturer[x]);
                    x = states.Length;
                    isState = true;
                }
            }
            if(isState)
            {
                
            }
            else
            {
                WriteLine("Sorry, no data for {0} state", inputString);
            }

        }
    }
}
