﻿
namespace Lab2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.enterMealLabel = new System.Windows.Forms.Label();
            this.tipPercent1 = new System.Windows.Forms.Label();
            this.tipPercent2 = new System.Windows.Forms.Label();
            this.tipPercent3 = new System.Windows.Forms.Label();
            this.calculateButton = new System.Windows.Forms.Button();
            this.mealPrice = new System.Windows.Forms.TextBox();
            this.tipAmount1 = new System.Windows.Forms.Label();
            this.tipAmount2 = new System.Windows.Forms.Label();
            this.tipAmount3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // enterMealLabel
            // 
            this.enterMealLabel.AutoSize = true;
            this.enterMealLabel.Location = new System.Drawing.Point(71, 69);
            this.enterMealLabel.Name = "enterMealLabel";
            this.enterMealLabel.Size = new System.Drawing.Size(198, 25);
            this.enterMealLabel.TabIndex = 0;
            this.enterMealLabel.Text = "Enter price of meal:";
            // 
            // tipPercent1
            // 
            this.tipPercent1.AutoSize = true;
            this.tipPercent1.Location = new System.Drawing.Point(214, 129);
            this.tipPercent1.Name = "tipPercent1";
            this.tipPercent1.Size = new System.Drawing.Size(55, 25);
            this.tipPercent1.TabIndex = 1;
            this.tipPercent1.Text = "15%";
            // 
            // tipPercent2
            // 
            this.tipPercent2.AutoSize = true;
            this.tipPercent2.Location = new System.Drawing.Point(214, 180);
            this.tipPercent2.Name = "tipPercent2";
            this.tipPercent2.Size = new System.Drawing.Size(55, 25);
            this.tipPercent2.TabIndex = 2;
            this.tipPercent2.Text = "18%";
            // 
            // tipPercent3
            // 
            this.tipPercent3.AutoSize = true;
            this.tipPercent3.Location = new System.Drawing.Point(214, 233);
            this.tipPercent3.Name = "tipPercent3";
            this.tipPercent3.Size = new System.Drawing.Size(55, 25);
            this.tipPercent3.TabIndex = 3;
            this.tipPercent3.Text = "20%";
            // 
            // calculateButton
            // 
            this.calculateButton.Location = new System.Drawing.Point(219, 316);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(158, 43);
            this.calculateButton.TabIndex = 4;
            this.calculateButton.Text = "Calculate Tip";
            this.calculateButton.UseVisualStyleBackColor = true;
            this.calculateButton.Click += new System.EventHandler(this.calculateButton_Click);
            // 
            // mealPrice
            // 
            this.mealPrice.Location = new System.Drawing.Point(286, 66);
            this.mealPrice.Name = "mealPrice";
            this.mealPrice.Size = new System.Drawing.Size(100, 31);
            this.mealPrice.TabIndex = 5;
            // 
            // tipAmount1
            // 
            this.tipAmount1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tipAmount1.Location = new System.Drawing.Point(286, 128);
            this.tipAmount1.Name = "tipAmount1";
            this.tipAmount1.Size = new System.Drawing.Size(100, 23);
            this.tipAmount1.TabIndex = 6;
            // 
            // tipAmount2
            // 
            this.tipAmount2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tipAmount2.Location = new System.Drawing.Point(286, 180);
            this.tipAmount2.Name = "tipAmount2";
            this.tipAmount2.Size = new System.Drawing.Size(100, 23);
            this.tipAmount2.TabIndex = 7;
            // 
            // tipAmount3
            // 
            this.tipAmount3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tipAmount3.Location = new System.Drawing.Point(286, 233);
            this.tipAmount3.Name = "tipAmount3";
            this.tipAmount3.Size = new System.Drawing.Size(100, 23);
            this.tipAmount3.TabIndex = 8;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tipAmount3);
            this.Controls.Add(this.tipAmount2);
            this.Controls.Add(this.tipAmount1);
            this.Controls.Add(this.mealPrice);
            this.Controls.Add(this.calculateButton);
            this.Controls.Add(this.tipPercent3);
            this.Controls.Add(this.tipPercent2);
            this.Controls.Add(this.tipPercent1);
            this.Controls.Add(this.enterMealLabel);
            this.Name = "Form1";
            this.Text = "Lab 2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label enterMealLabel;
        private System.Windows.Forms.Label tipPercent1;
        private System.Windows.Forms.Label tipPercent2;
        private System.Windows.Forms.Label tipPercent3;
        private System.Windows.Forms.Button calculateButton;
        private System.Windows.Forms.TextBox mealPrice;
        private System.Windows.Forms.Label tipAmount1;
        private System.Windows.Forms.Label tipAmount2;
        private System.Windows.Forms.Label tipAmount3;
    }
}

