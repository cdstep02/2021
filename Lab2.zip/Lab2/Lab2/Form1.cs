﻿//Grading ID: K5060
//Lab Number: 2
//Due Date: 2/7/2021
//Course Section: CIS 199-75
//Breif Description: This lab creates a windows form application that serves as a tip calculator. When the user enters the price of their meal into the calculator it will calculate and display tips for 15%, 18%, and 20%.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //This click event multiplies the input by the three named constants listed below
        private void calculateButton_Click(object sender, EventArgs e)
        {
            //In the following code variables will be declared and constants will be named
            const double TIP_RATE1 = .15; //naming the first constant
            const double TIP_RATE2 = .18; //naming the second constant
            const double TIP_RATE3 = .20; //naming the third constant
            double product1; //declaring the variable
            double product2; //declaring the variable
            double product3; //declaring the variable
            double convertedMealPrice; //declaring the variable
            //In the following code the input will be collected and calculations will be made
            convertedMealPrice = Convert.ToDouble(mealPrice.Text); //This code collects the input and converts it to a double
            product1 = convertedMealPrice * TIP_RATE1; //this code performs the 1st calculation
            tipAmount1.Text = product1.ToString("C2"); //this code converts the product from the 1st calculation into a currency format with two numbers right of the decimal
            product2 = convertedMealPrice * TIP_RATE2; //this code peforms the 2nd calculation
            tipAmount2.Text = product2.ToString("C2"); // this code converts the product from the 2nd calculation into a currency format with two numbers right of the decimal
            product3 = convertedMealPrice * TIP_RATE3; //this code performs the 3rd calculation
            tipAmount3.Text = product3.ToString("C2"); //this code converts the product from the 3rd calculation into a currency format with two numbers right of the decimal

            
        }
    }
}
