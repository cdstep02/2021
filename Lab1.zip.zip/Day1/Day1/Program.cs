﻿//Grading Id:K5060
//Lab number:1
//Due Date:1/24/2021
//Course Section:CIS199-75
//Brief Description:Tell the reader some personal facts and my grading id.
using System;

namespace Lab1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Grade ID:        K5060");
            Console.WriteLine("Hobbies:         Watching TV and chilling with my dog");
            Console.WriteLine("Favorite Book:   Diary of a Wimpy Kid");
            Console.WriteLine("Favorite Movie:  Transformers");
        }
    }
}
