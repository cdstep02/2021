﻿//Grade ID: K5060
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CIS199E1S21
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calcButton_Click(object sender, EventArgs e)
        {
            int number; //reprsents converted user input
            number = int.Parse(userInput.Text); // converts user input
            //below is the if-else statement that evaluates the values
            if (number <= 55)
            {
                outputLabel.Text = ("The human development level is low");
            }
            else if (number <= 69)
            {
                outputLabel.Text = ("The human development level is medium");
            }
            else if (number <= 79)
            {
                outputLabel.Text = ("The human development level is high");
            }
            else
            {
                outputLabel.Text = ("The human development level is very high");
            }
        }
    }
}
